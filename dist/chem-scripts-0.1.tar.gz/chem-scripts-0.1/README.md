# cheminfo-scripts
Set of python scripts that may be useful for cheminfomatics
